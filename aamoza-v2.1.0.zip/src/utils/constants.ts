import type { FileMap, ProviderConfig } from '../types'

export const APP_NAME = 'Aamoza'
export const APP_VERSION = '2.1.0'
export const APP_AUTHOR = 'aamoza'
export const APP_TAGLINE = 'AI Android Maker'

export const PROVIDERS: ProviderConfig[] = [
  {
    id: 'gemini',
    name: 'Google Gemini',
    models: ['gemini-2.0-flash', 'gemini-2.0-flash-lite', 'gemini-1.5-pro', 'gemini-1.5-flash'],
    defaultModel: 'gemini-2.0-flash',
    docsUrl: 'https://aistudio.google.com/apikey',
    keyPlaceholder: 'AIza...',
  },
  {
    id: 'deepseek',
    name: 'DeepSeek',
    models: ['deepseek-chat', 'deepseek-reasoner'],
    defaultModel: 'deepseek-chat',
    docsUrl: 'https://platform.deepseek.com/api_keys',
    keyPlaceholder: 'sk-...',
  },
]

export const SYSTEM_PROMPT = `You are an expert Android developer assistant specialized in Kotlin and Jetpack Compose.

You help users create and modify Android applications. When the user asks you to create or change code, you MUST respond with a valid JSON object only (no markdown fences, no extra text outside JSON).

JSON schema:
{
  "message": "Short friendly explanation for the user",
  "files": {
    "path/to/file.kt": "complete file content as string"
  },
  "delete": ["optional/paths/to/remove"]
}

Rules:
- All generated Android projects live under the prefix "generated-app/".
- Always produce complete, compilable files (not snippets).
- Prefer Jetpack Compose + Material 3 + Kotlin.
- Target SDK 35, minSdk 26, Java/Kotlin 17.
- Keep package name com.example.aamoza unless the user requests otherwise.
- If the user only asks a question (no code change needed), return only {"message": "your answer"} without files.
- Never include API keys, secrets, or personal tokens in any file.
- Paths must use forward slashes and start with generated-app/ when creating project files.
- Include or update gradle wrapper files when needed for reliable builds.
- When explaining code, be clear and educational.`

export const PROMPT_TEMPLATES = [
  { id: 'counter', label: 'Counter App', prompt: 'Create a simple Material 3 counter app with + and - buttons and a reset button.' },
  { id: 'todo', label: 'Todo List', prompt: 'Create a Todo List app with Compose. Users can add, toggle complete, and delete tasks. Persist nothing for now.' },
  { id: 'weather', label: 'Weather UI', prompt: 'Create a weather app UI (mock data) showing current temperature, condition, and a 5-day forecast list with Material 3 cards.' },
  { id: 'calc', label: 'Calculator', prompt: 'Create a simple calculator app with basic operations (+, -, *, /) using Jetpack Compose and Material 3.' },
  { id: 'nav', label: 'Bottom Nav', prompt: 'Add a bottom navigation bar with 3 tabs: Home, Search, and Profile. Each tab shows a simple placeholder screen.' },
  { id: 'theme', label: 'Dark/Light Theme', prompt: 'Add a dark/light theme toggle that switches the entire app theme using Material 3 color schemes.' },
]

export const INITIAL_TEMPLATE: FileMap = {
  'generated-app/settings.gradle.kts': `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(org.gradle.api.initialization.resolve.RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "Aamoza Generated App"
include(":app")
`,
  'generated-app/build.gradle.kts': `plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
`,
  'generated-app/gradle.properties': `org.gradle.jvmargs=-Xmx2g -Dfile.encoding=UTF-8
android.useAndroidX=true
kotlin.code.style=official
android.nonTransitiveRClass=true
`,
  'generated-app/gradle/wrapper/gradle-wrapper.properties': `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.7-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`,
  'generated-app/gradlew': `#!/bin/sh
# Gradle start-up script (simplified for Aamoza template)
# For full production use, replace with official Gradle Wrapper from Android Studio.
DIR="$(cd "$(dirname "$0")" && pwd)"
if [ -f "$DIR/gradle/wrapper/gradle-wrapper.jar" ]; then
  exec java -jar "$DIR/gradle/wrapper/gradle-wrapper.jar" "$@"
else
  echo "gradle-wrapper.jar not found. Using system gradle if available."
  exec gradle "$@"
fi
`,
  'generated-app/app/build.gradle.kts': `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.aamoza"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.aamoza"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
}

dependencies {
    val bom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(bom)
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
`,
  'generated-app/app/src/main/AndroidManifest.xml': `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application
        android:allowBackup="true"
        android:label="Aamoza App"
        android:supportsRtl="true"
        android:theme="@style/Theme.Aamoza">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.Aamoza">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`,
  'generated-app/app/src/main/java/com/example/aamoza/MainActivity.kt': `package com.example.aamoza

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    GreetingScreen()
                }
            }
        }
    }
}

@Composable
fun GreetingScreen() {
    var count by remember { mutableStateOf(0) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Hello from Aamoza!",
            style = MaterialTheme.typography.headlineSmall
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "AI Android Maker",
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(modifier = Modifier.height(24.dp))
        Text("You clicked $count times")
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = { count++ }) {
            Text("Click me")
        }
    }
}
`,
  'generated-app/app/src/main/res/values/strings.xml': `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">Aamoza App</string>
</resources>
`,
  'generated-app/app/src/main/res/values/themes.xml': `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.Aamoza" parent="android:Theme.Material.Light.NoActionBar" />
</resources>
`,
  'generated-app/local.properties.example': `# Copy to local.properties and set your Android SDK path
# sdk.dir=/path/to/Android/sdk
`,
}

export const BNB_WALLET = '0xC47C7382F5D2EF81d6A5698fB1acFAe7A2FBC8f2'

export const MAX_CONTEXT_FILES = 25
export const MAX_FILE_CHARS = 12000

export const WORKFLOW_CONTENT = `name: Build Android APK

on:
  push:
    paths:
      - 'generated-app/**'
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    timeout-minutes: 30

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 17

      - name: Setup Android SDK
        uses: android-actions/setup-android@v3

      - name: Grant execute permission for gradlew
        working-directory: generated-app
        run: |
          if [ -f gradlew ]; then
            chmod +x gradlew
          fi

      - name: Setup Gradle
        uses: gradle/actions/setup-gradle@v3
        with:
          gradle-version: 8.7

      - name: Build debug APK
        working-directory: generated-app
        run: |
          if [ -f gradlew ]; then
            ./gradlew assembleDebug --no-daemon --stacktrace
          else
            gradle assembleDebug --no-daemon --stacktrace
          fi

      - name: Upload APK artifact
        uses: actions/upload-artifact@v4
        with:
          name: android-debug-apk
          path: |
            generated-app/app/build/outputs/apk/debug/*.apk
          if-no-files-found: warn
          retention-days: 14
`
