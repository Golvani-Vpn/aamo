import type { AIResponse } from '../../types'
import { SYSTEM_PROMPT } from '../constants'

function extractJson(text: string): AIResponse {
  try {
    const parsed = JSON.parse(text)
    if (parsed && typeof parsed.message === 'string') {
      return {
        message: parsed.message,
        files: parsed.files && typeof parsed.files === 'object' ? parsed.files : undefined,
        delete: Array.isArray(parsed.delete) ? parsed.delete : undefined,
      }
    }
  } catch { /* continue */ }

  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/)
  if (fence) {
    try {
      const parsed = JSON.parse(fence[1].trim())
      if (parsed && typeof parsed.message === 'string') {
        return {
          message: parsed.message,
          files: parsed.files && typeof parsed.files === 'object' ? parsed.files : undefined,
          delete: Array.isArray(parsed.delete) ? parsed.delete : undefined,
        }
      }
    } catch { /* continue */ }
  }

  const start = text.indexOf('{')
  const end = text.lastIndexOf('}')
  if (start !== -1 && end > start) {
    try {
      const parsed = JSON.parse(text.slice(start, end + 1))
      if (parsed && typeof parsed.message === 'string') {
        return {
          message: parsed.message,
          files: parsed.files && typeof parsed.files === 'object' ? parsed.files : undefined,
          delete: Array.isArray(parsed.delete) ? parsed.delete : undefined,
        }
      }
    } catch { /* continue */ }
  }

  return { message: text.trim() || 'No response from model.' }
}

export async function testDeepSeekConnection(apiKey: string, model: string): Promise<string> {
  const res = await fetch('https://api.deepseek.com/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages: [{ role: 'user', content: 'Reply with exactly: OK' }],
      max_tokens: 16,
      temperature: 0,
    }),
  })

  if (res.status === 401) throw new Error('Invalid API Key')
  if (res.status === 429) throw new Error('API quota exceeded')
  if (res.status === 404) throw new Error('Model unavailable')
  if (!res.ok) {
    const body = await res.json().catch(() => ({}))
    throw new Error(body?.error?.message || `Network error (${res.status})`)
  }

  return 'DeepSeek API Connected ✓'
}

async function callDeepSeek(
  apiKey: string,
  model: string,
  messages: { role: string; content: string }[]
): Promise<string> {
  const res = await fetch('https://api.deepseek.com/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages,
      temperature: 0.4,
      max_tokens: 8192,
    }),
  })

  if (res.status === 429) throw new Error('API quota exceeded')
  if (res.status === 401) throw new Error('Invalid API Key')
  if (!res.ok) {
    const err = await res.json().catch(() => ({}))
    throw new Error(err?.error?.message || `DeepSeek error (${res.status})`)
  }

  const data = await res.json()
  const text = data?.choices?.[0]?.message?.content
  if (!text) throw new Error('Empty response from DeepSeek')
  return text
}

export async function chatDeepSeek(
  apiKey: string,
  model: string,
  userMessage: string,
  history: { role: string; content: string }[],
  projectContext: string
): Promise<AIResponse> {
  const messages: { role: string; content: string }[] = [
    {
      role: 'system',
      content: SYSTEM_PROMPT + (projectContext ? `\n\nCurrent project files:\n${projectContext}` : ''),
    },
  ]

  for (const m of history.slice(-12)) {
    messages.push({ role: m.role === 'assistant' ? 'assistant' : 'user', content: m.content })
  }
  // Ensure last is the current user message
  if (messages[messages.length - 1]?.content !== userMessage) {
    messages.push({ role: 'user', content: userMessage })
  }

  let text = await callDeepSeek(apiKey, model, messages)
  let response = extractJson(text)

  if (response.files && Object.keys(response.files).length > 0) {
    const incomplete = Object.entries(response.files).some(
      ([, body]) => !body || body.length < 20 || body.includes('TODO: implement')
    )
    if (incomplete) {
      try {
        text = await callDeepSeek(apiKey, model, [
          ...messages,
          { role: 'assistant', content: text },
          {
            role: 'user',
            content:
              'Your previous JSON had incomplete or placeholder file contents. Please respond again with COMPLETE file contents for every path in "files". Return valid JSON only.',
          },
        ])
        response = extractJson(text)
      } catch {
        // keep original
      }
    }
  }

  return response
}

export async function explainCodeDeepSeek(
  apiKey: string,
  model: string,
  path: string,
  content: string
): Promise<string> {
  const prompt = `Explain the following Android/Kotlin file in clear English. Cover purpose, key components, and how it fits in a typical app. Be concise but educational.\n\nFile: ${path}\n\n\`\`\`\n${content.slice(0, 8000)}\n\`\`\``
  return callDeepSeek(apiKey, model, [
    { role: 'system', content: 'You are a helpful Android development tutor.' },
    { role: 'user', content: prompt },
  ])
}
