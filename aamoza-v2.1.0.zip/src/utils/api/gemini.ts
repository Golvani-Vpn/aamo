import type { AIResponse } from '../../types'
import { SYSTEM_PROMPT } from '../constants'

function extractJson(text: string): AIResponse {
  try {
    const parsed = JSON.parse(text)
    if (parsed && typeof parsed.message === 'string') {
      return {
        message: parsed.message,
        files: parsed.files && typeof parsed.files === 'object' ? parsed.files : undefined,
        delete: Array.isArray(parsed.delete) ? parsed.delete : undefined,
      }
    }
  } catch { /* continue */ }

  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/)
  if (fence) {
    try {
      const parsed = JSON.parse(fence[1].trim())
      if (parsed && typeof parsed.message === 'string') {
        return {
          message: parsed.message,
          files: parsed.files && typeof parsed.files === 'object' ? parsed.files : undefined,
          delete: Array.isArray(parsed.delete) ? parsed.delete : undefined,
        }
      }
    } catch { /* continue */ }
  }

  const start = text.indexOf('{')
  const end = text.lastIndexOf('}')
  if (start !== -1 && end > start) {
    try {
      const parsed = JSON.parse(text.slice(start, end + 1))
      if (parsed && typeof parsed.message === 'string') {
        return {
          message: parsed.message,
          files: parsed.files && typeof parsed.files === 'object' ? parsed.files : undefined,
          delete: Array.isArray(parsed.delete) ? parsed.delete : undefined,
        }
      }
    } catch { /* continue */ }
  }

  return { message: text.trim() || 'No response from model.' }
}

export async function testGeminiConnection(apiKey: string, model: string): Promise<string> {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(apiKey)}`
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ role: 'user', parts: [{ text: 'Reply with exactly: OK' }] }],
      generationConfig: { maxOutputTokens: 16, temperature: 0 },
    }),
  })

  if (res.status === 400) {
    const body = await res.json().catch(() => ({}))
    const msg = body?.error?.message || 'Bad request'
    if (/API key|invalid|not valid/i.test(msg)) throw new Error('Invalid API Key')
    throw new Error(msg)
  }
  if (res.status === 401 || res.status === 403) throw new Error('Invalid API Key')
  if (res.status === 429) throw new Error('API quota exceeded')
  if (res.status === 404) throw new Error('Model unavailable')
  if (!res.ok) {
    const body = await res.json().catch(() => ({}))
    throw new Error(body?.error?.message || `Network error (${res.status})`)
  }

  const data = await res.json()
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text
  if (!text) throw new Error('Empty response from Gemini')
  return 'Gemini API Connected ✓'
}

async function callGemini(
  apiKey: string,
  model: string,
  contents: { role: string; parts: { text?: string; inlineData?: { mimeType: string; data: string } }[] }[],
  systemInstruction?: string
): Promise<string> {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(apiKey)}`
  const body: any = {
    contents,
    generationConfig: { temperature: 0.4, maxOutputTokens: 8192 },
  }
  if (systemInstruction) {
    body.systemInstruction = { parts: [{ text: systemInstruction }] }
  }

  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })

  if (res.status === 429) throw new Error('API quota exceeded')
  if (res.status === 401 || res.status === 403) throw new Error('Invalid API Key')
  if (!res.ok) {
    const err = await res.json().catch(() => ({}))
    throw new Error(err?.error?.message || `Gemini error (${res.status})`)
  }

  const data = await res.json()
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text
  if (!text) throw new Error('Empty response from Gemini')
  return text
}

export async function chatGemini(
  apiKey: string,
  model: string,
  userMessage: string,
  history: { role: string; content: string }[],
  projectContext: string,
  imageBase64?: string | null
): Promise<AIResponse> {
  const contents: { role: string; parts: any[] }[] = []

  // System via first turns
  contents.push({
    role: 'user',
    parts: [{ text: SYSTEM_PROMPT + (projectContext ? `\n\nCurrent project files:\n${projectContext}` : '') }],
  })
  contents.push({ role: 'model', parts: [{ text: '{"message":"Ready. How can I help you build your Android app?"}' }] })

  // History (skip last user – we add it with possible image)
  const prior = history.slice(0, -1)
  for (const m of prior.slice(-10)) {
    contents.push({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }],
    })
  }

  const userParts: any[] = [{ text: userMessage }]
  if (imageBase64) {
    const pure = imageBase64.replace(/^data:image\/\w+;base64,/, '')
    userParts.unshift({
      inlineData: { mimeType: 'image/png', data: pure },
    })
  }
  contents.push({ role: 'user', parts: userParts })

  let text = await callGemini(apiKey, model, contents)
  let response = extractJson(text)

  // Self-repair loop if files look incomplete
  if (response.files && Object.keys(response.files).length > 0) {
    const incomplete = Object.entries(response.files).some(
      ([, body]) => !body || body.length < 20 || body.includes('TODO: implement')
    )
    if (incomplete) {
      const repairContents = [
        ...contents,
        { role: 'model', parts: [{ text }] },
        {
          role: 'user',
          parts: [{
            text: 'Your previous JSON had incomplete or placeholder file contents. Please respond again with COMPLETE file contents for every path in "files". Return valid JSON only.',
          }],
        },
      ]
      try {
        text = await callGemini(apiKey, model, repairContents)
        response = extractJson(text)
      } catch {
        // keep original
      }
    }
  }

  return response
}

export async function explainCodeGemini(
  apiKey: string,
  model: string,
  path: string,
  content: string
): Promise<string> {
  const prompt = `Explain the following Android/Kotlin file in clear English. Cover purpose, key components, and how it fits in a typical app. Be concise but educational.\n\nFile: ${path}\n\n\`\`\`\n${content.slice(0, 8000)}\n\`\`\``
  const text = await callGemini(apiKey, model, [{ role: 'user', parts: [{ text: prompt }] }])
  return text
}
