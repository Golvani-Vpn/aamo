import type { FileMap } from '../types'
import { WORKFLOW_CONTENT } from './constants'

async function gh(
  path: string,
  token: string,
  options: RequestInit = {}
): Promise<any> {
  const res = await fetch(`https://api.github.com${path}`, {
    ...options,
    headers: {
      Accept: 'application/vnd.github+json',
      Authorization: `Bearer ${token}`,
      'X-GitHub-Api-Version': '2022-11-28',
      ...(options.headers || {}),
    },
  })

  if (res.status === 401) throw new Error('Invalid GitHub token')
  if (res.status === 403) {
    const body = await res.json().catch(() => ({}))
    if (body?.message?.includes('rate limit')) throw new Error('GitHub rate limit exceeded')
    throw new Error('GitHub permission denied – check token scopes (Contents: Read and write)')
  }
  if (res.status === 404) throw new Error('Repository not found or token lacks access')
  if (!res.ok) {
    const body = await res.json().catch(() => ({}))
    throw new Error(body?.message || `GitHub error (${res.status})`)
  }
  if (res.status === 204) return null
  return res.json()
}

function toBase64(str: string): string {
  return btoa(unescape(encodeURIComponent(str)))
}

export async function testGitHubConnection(
  owner: string,
  repo: string,
  token: string
): Promise<string> {
  if (!owner.trim() || !repo.trim() || !token.trim()) {
    throw new Error('Owner, repository and token are required')
  }

  const info = await gh(`/repos/${owner.trim()}/${repo.trim()}`, token)
  if (!info?.full_name) throw new Error('Could not read repository')

  await gh(`/repos/${owner.trim()}/${repo.trim()}/contents/`, token).catch(() => {})

  return `Connected to ${info.full_name} ✓`
}

export async function ensureWorkflow(
  owner: string,
  repo: string,
  token: string
): Promise<void> {
  const o = owner.trim()
  const r = repo.trim()
  const path = '.github/workflows/build-android.yml'
  try {
    await gh(`/repos/${o}/${r}/contents/${path}`, token)
    // exists
  } catch {
    // create it via contents API (simple single-file create)
    await gh(`/repos/${o}/${r}/contents/${path}`, token, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: 'Aamoza: add Android build workflow',
        content: toBase64(WORKFLOW_CONTENT),
      }),
    })
  }
}

export async function pushFilesToGitHub(
  owner: string,
  repo: string,
  token: string,
  files: FileMap,
  commitMessage = 'Aamoza: generate/update Android app'
): Promise<{ commitSha: string; branch: string }> {
  const o = owner.trim()
  const r = repo.trim()

  // Ensure workflow exists
  try {
    await ensureWorkflow(o, r, token)
  } catch {
    // non-fatal – user can add manually
  }

  const info = await gh(`/repos/${o}/${r}`, token)
  const branch: string = info.default_branch || 'main'

  let ref: any
  try {
    ref = await gh(`/repos/${o}/${r}/git/ref/heads/${encodeURIComponent(branch)}`, token)
  } catch {
    throw new Error('Repository is empty. Push an initial commit (e.g. README) first.')
  }

  const baseCommit = await gh(`/repos/${o}/${r}/git/commits/${ref.object.sha}`, token)

  const treeItems: { path: string; mode: string; type: string; sha: string }[] = []
  for (const [path, content] of Object.entries(files)) {
    const blob = await gh(`/repos/${o}/${r}/git/blobs`, token, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: toBase64(String(content)), encoding: 'base64' }),
    })
    treeItems.push({ path, mode: '100644', type: 'blob', sha: blob.sha })
  }

  const tree = await gh(`/repos/${o}/${r}/git/trees`, token, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ base_tree: baseCommit.tree.sha, tree: treeItems }),
  })

  const commit = await gh(`/repos/${o}/${r}/git/commits`, token, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      message: commitMessage,
      tree: tree.sha,
      parents: [baseCommit.sha],
    }),
  })

  await gh(`/repos/${o}/${r}/git/refs/heads/${encodeURIComponent(branch)}`, token, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ sha: commit.sha, force: false }),
  })

  return { commitSha: commit.sha, branch }
}

export async function getLatestWorkflowRun(
  owner: string,
  repo: string,
  token: string,
  workflowFile = 'build-android.yml'
): Promise<{ html_url: string; status: string; conclusion: string | null; id?: number } | null> {
  try {
    const data = await gh(
      `/repos/${owner.trim()}/${repo.trim()}/actions/workflows/${workflowFile}/runs?per_page=1`,
      token
    )
    const run = data?.workflow_runs?.[0]
    if (!run) return null
    return {
      html_url: run.html_url,
      status: run.status,
      conclusion: run.conclusion,
      id: run.id,
    }
  } catch {
    return null
  }
}

export async function getArtifactDownloadHint(
  owner: string,
  repo: string,
  token: string,
  runId: number
): Promise<string | null> {
  try {
    const data = await gh(
      `/repos/${owner.trim()}/${repo.trim()}/actions/runs/${runId}/artifacts`,
      token
    )
    const art = data?.artifacts?.[0]
    if (art) {
      return `Artifact "${art.name}" ready – download from the workflow run page (Artifacts section).`
    }
  } catch {}
  return null
}
