import type { FileMap } from '../types'
import { MAX_CONTEXT_FILES, MAX_FILE_CHARS } from './constants'

/** Build a smart, size-limited project context for the AI */
export function buildProjectContext(files: FileMap): string {
  const entries = Object.entries(files)
  if (entries.length === 0) return ''

  // Prefer important files first
  const priority = (path: string) => {
    if (path.endsWith('MainActivity.kt') || path.endsWith('MainActivity.java')) return 0
    if (path.includes('/java/') || path.includes('/kotlin/')) return 1
    if (path.endsWith('.kt') || path.endsWith('.java')) return 2
    if (path.includes('build.gradle') || path.includes('AndroidManifest')) return 3
    if (path.includes('res/')) return 4
    return 5
  }

  const sorted = [...entries].sort((a, b) => priority(a[0]) - priority(b[0]))
  const selected = sorted.slice(0, MAX_CONTEXT_FILES)

  const parts: string[] = []
  let total = 0

  for (const [path, content] of selected) {
    let body = content
    if (body.length > MAX_FILE_CHARS) {
      body = body.slice(0, MAX_FILE_CHARS) + '\n… [truncated]'
    }
    const chunk = `--- ${path} ---\n${body}\n`
    if (total + chunk.length > 80000) break
    parts.push(chunk)
    total += chunk.length
  }

  const omitted = entries.length - selected.length
  if (omitted > 0) {
    parts.push(`\n(${omitted} additional files omitted for context size)`)
  }

  return parts.join('\n')
}
