export type AIProvider = 'gemini' | 'deepseek'

export type ConnectionStatus = 'idle' | 'testing' | 'connected' | 'error'

export type ChatRole = 'user' | 'assistant' | 'system'

export interface ChatMessage {
  id: string
  role: ChatRole
  content: string
  timestamp: number
}

export interface AIResponse {
  message: string
  files?: Record<string, string>
  delete?: string[]
}

export interface FileMap {
  [path: string]: string
}

export interface BuildInfo {
  status: 'idle' | 'pushing' | 'building' | 'success' | 'failed'
  message: string
  runUrl?: string
  apkUrl?: string
}

export interface ProviderConfig {
  id: AIProvider
  name: string
  models: string[]
  defaultModel: string
  docsUrl: string
  keyPlaceholder: string
}

export interface ChatSession {
  id: string
  title: string
  messages: ChatMessage[]
  files: FileMap
  createdAt: number
  updatedAt: number
}

export type ProgressStep = 'idle' | 'ai' | 'code' | 'github' | 'build'
