import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type {
  AIProvider,
  BuildInfo,
  ChatMessage,
  ChatSession,
  ConnectionStatus,
  FileMap,
  ProgressStep,
} from './types'
import {
  APP_NAME,
  APP_VERSION,
  APP_AUTHOR,
  APP_TAGLINE,
  PROVIDERS,
  INITIAL_TEMPLATE,
  BNB_WALLET,
  PROMPT_TEMPLATES,
} from './utils/constants'
import { testGeminiConnection, chatGemini, explainCodeGemini } from './utils/api/gemini'
import { testDeepSeekConnection, chatDeepSeek, explainCodeDeepSeek } from './utils/api/deepseek'
import {
  testGitHubConnection,
  pushFilesToGitHub,
  getLatestWorkflowRun,
  getArtifactDownloadHint,
} from './utils/githubApi'
import { buildProjectContext } from './utils/context'

declare global {
  interface Window {
    JSZip?: any
    Prism?: any
  }
}

function uid() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36)
}

const STORAGE_SESSIONS = 'aamoza_sessions_v1'
const STORAGE_KEYS = 'aamoza_keys_v1'

function loadSessions(): ChatSession[] {
  try {
    const raw = localStorage.getItem(STORAGE_SESSIONS)
    if (!raw) return []
    return JSON.parse(raw)
  } catch {
    return []
  }
}

function saveSessions(sessions: ChatSession[]) {
  try {
    localStorage.setItem(STORAGE_SESSIONS, JSON.stringify(sessions.slice(0, 20)))
  } catch { /* quota */ }
}

function loadPersistedKeys(): { apiKey?: string; ghToken?: string; provider?: AIProvider } {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS)
    if (!raw) return {}
    return JSON.parse(raw)
  } catch {
    return {}
  }
}

function langForPath(path: string): string {
  if (path.endsWith('.kt') || path.endsWith('.kts')) return 'kotlin'
  if (path.endsWith('.xml')) return 'xml'
  if (path.endsWith('.gradle') || path.endsWith('.properties')) return 'properties'
  if (path.endsWith('.json')) return 'json'
  if (path.endsWith('.md')) return 'markdown'
  return 'plaintext'
}

export default function App() {
  // AI
  const [provider, setProvider] = useState<AIProvider>('gemini')
  const [model, setModel] = useState(PROVIDERS[0].defaultModel)
  const [apiKey, setApiKey] = useState('')
  const [showApiKey, setShowApiKey] = useState(false)
  const [aiStatus, setAiStatus] = useState<ConnectionStatus>('idle')
  const [aiStatusMsg, setAiStatusMsg] = useState('')

  // GitHub
  const [ghOwner, setGhOwner] = useState('')
  const [ghRepo, setGhRepo] = useState('')
  const [ghToken, setGhToken] = useState('')
  const [showGhToken, setShowGhToken] = useState(false)
  const [ghStatus, setGhStatus] = useState<ConnectionStatus>('idle')
  const [ghStatusMsg, setGhStatusMsg] = useState('')

  // Persist keys option
  const [persistKeys, setPersistKeys] = useState(false)

  // Sessions / Chat
  const [sessions, setSessions] = useState<ChatSession[]>(() => loadSessions())
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null)
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)

  // Project files
  const [files, setFiles] = useState<FileMap>({ ...INITIAL_TEMPLATE })
  const [selectedFile, setSelectedFile] = useState<string | null>(null)
  const [prevFiles, setPrevFiles] = useState<FileMap>({})
  const [explainText, setExplainText] = useState<string | null>(null)

  // Build
  const [build, setBuild] = useState<BuildInfo>({ status: 'idle', message: '' })

  // UI
  const [showGuide, setShowGuide] = useState(false)
  const [showHistory, setShowHistory] = useState(false)
  const [toast, setToast] = useState<{ text: string; type: 'ok' | 'err' } | null>(null)
  const [progress, setProgress] = useState<ProgressStep>('idle')
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const providerCfg = useMemo(
    () => PROVIDERS.find((p) => p.id === provider)!,
    [provider]
  )

  // Restore persisted keys
  useEffect(() => {
    const k = loadPersistedKeys()
    if (k.apiKey) setApiKey(k.apiKey)
    if (k.ghToken) setGhToken(k.ghToken)
    if (k.provider) setProvider(k.provider)
    if (k.apiKey || k.ghToken) setPersistKeys(true)
  }, [])

  useEffect(() => {
    setModel(providerCfg.defaultModel)
    setAiStatus('idle')
    setAiStatusMsg('')
  }, [provider, providerCfg])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, busy])

  // Highlight selected file
  useEffect(() => {
    if (selectedFile && window.Prism) {
      setTimeout(() => window.Prism.highlightAll(), 50)
    }
  }, [selectedFile, files])

  // Persist keys when option on
  useEffect(() => {
    if (persistKeys) {
      try {
        localStorage.setItem(
          STORAGE_KEYS,
          JSON.stringify({ apiKey, ghToken, provider })
        )
      } catch {}
    } else {
      localStorage.removeItem(STORAGE_KEYS)
    }
  }, [persistKeys, apiKey, ghToken, provider])

  const showToast = (text: string, type: 'ok' | 'err' = 'ok') => {
    setToast({ text, type })
    setTimeout(() => setToast(null), 4200)
  }

  const persistCurrentSession = useCallback(
    (msgs: ChatMessage[], fls: FileMap) => {
      const title =
        msgs.find((m) => m.role === 'user')?.content.slice(0, 48) || 'New chat'
      const now = Date.now()
      setSessions((prev) => {
        let next: ChatSession[]
        if (activeSessionId) {
          next = prev.map((s) =>
            s.id === activeSessionId
              ? { ...s, title, messages: msgs, files: fls, updatedAt: now }
              : s
          )
        } else {
          const id = uid()
          setActiveSessionId(id)
          next = [
            { id, title, messages: msgs, files: fls, createdAt: now, updatedAt: now },
            ...prev,
          ]
        }
        saveSessions(next)
        return next
      })
    },
    [activeSessionId]
  )

  // ---- AI Connection Test ----
  const testAI = async () => {
    if (!apiKey.trim()) {
      setAiStatus('error')
      setAiStatusMsg('Please enter an API key')
      return
    }
    setAiStatus('testing')
    setAiStatusMsg('Testing connection…')
    setProgress('ai')
    try {
      let msg: string
      if (provider === 'gemini') {
        msg = await testGeminiConnection(apiKey.trim(), model)
      } else {
        msg = await testDeepSeekConnection(apiKey.trim(), model)
      }
      setAiStatus('connected')
      setAiStatusMsg(msg)
      showToast(msg, 'ok')
    } catch (e: any) {
      setAiStatus('error')
      setAiStatusMsg(e.message || 'Connection failed')
      showToast(e.message || 'Connection failed', 'err')
      setProgress('idle')
    }
  }

  // ---- GitHub Connection Test ----
  const testGitHub = async () => {
    setGhStatus('testing')
    setGhStatusMsg('Testing connection…')
    try {
      const msg = await testGitHubConnection(ghOwner, ghRepo, ghToken)
      setGhStatus('connected')
      setGhStatusMsg(msg)
      showToast(msg, 'ok')
      setProgress('github')
    } catch (e: any) {
      setGhStatus('error')
      setGhStatusMsg(e.message || 'Connection failed')
      showToast(e.message || 'Connection failed', 'err')
    }
  }

  // ---- Chat ----
  const sendMessage = useCallback(
    async (text?: string) => {
      const content = (text ?? input).trim()
      if (!content || busy) return
      if (aiStatus !== 'connected') {
        showToast('Test AI connection first', 'err')
        return
      }

      const userMsg: ChatMessage = {
        id: uid(),
        role: 'user',
        content: imagePreview ? `[Image attached]\n${content}` : content,
        timestamp: Date.now(),
      }
      const nextMessages = [...messages, userMsg]
      setMessages(nextMessages)
      setInput('')
      setBusy(true)
      setProgress('code')
      setPrevFiles({ ...files })

      try {
        const history = nextMessages
          .filter((m) => m.role === 'user' || m.role === 'assistant')
          .map((m) => ({ role: m.role, content: m.content }))

        const ctx = buildProjectContext(files)

        let response
        if (provider === 'gemini') {
          response = await chatGemini(
            apiKey.trim(),
            model,
            content,
            history,
            ctx,
            imagePreview
          )
        } else {
          response = await chatDeepSeek(apiKey.trim(), model, content, history, ctx)
        }

        setImagePreview(null)

        let updatedFiles = files
        if (response.files || response.delete) {
          updatedFiles = { ...files }
          if (response.files) {
            for (const [path, body] of Object.entries(response.files)) {
              updatedFiles[path] = body
            }
          }
          if (response.delete) {
            for (const path of response.delete) {
              delete updatedFiles[path]
            }
          }
          setFiles(updatedFiles)
        }

        const assistantMsg: ChatMessage = {
          id: uid(),
          role: 'assistant',
          content: response.message || 'Done.',
          timestamp: Date.now(),
        }
        const finalMsgs = [...nextMessages, assistantMsg]
        setMessages(finalMsgs)
        persistCurrentSession(finalMsgs, updatedFiles)
      } catch (e: any) {
        setMessages((prev) => [
          ...prev,
          {
            id: uid(),
            role: 'assistant',
            content: `Error: ${e.message || 'Request failed'}`,
            timestamp: Date.now(),
          },
        ])
        showToast(e.message || 'AI request failed', 'err')
      } finally {
        setBusy(false)
      }
    },
    [input, busy, aiStatus, messages, files, provider, apiKey, model, imagePreview, persistCurrentSession]
  )

  const newChat = () => {
    setMessages([])
    setInput('')
    setActiveSessionId(null)
    setFiles({ ...INITIAL_TEMPLATE })
    setSelectedFile(null)
    setExplainText(null)
    setPrevFiles({})
    setProgress(aiStatus === 'connected' ? 'ai' : 'idle')
  }

  const loadSession = (s: ChatSession) => {
    setActiveSessionId(s.id)
    setMessages(s.messages)
    setFiles(s.files)
    setSelectedFile(null)
    setExplainText(null)
    setShowHistory(false)
  }

  const deleteSession = (id: string) => {
    setSessions((prev) => {
      const next = prev.filter((s) => s.id !== id)
      saveSessions(next)
      return next
    })
    if (activeSessionId === id) newChat()
  }

  // ---- Download ZIP ----
  const downloadZip = async () => {
    if (!window.JSZip) {
      showToast('JSZip not loaded yet – try again in a moment', 'err')
      return
    }
    try {
      const zip = new window.JSZip()
      for (const [path, content] of Object.entries(files)) {
        zip.file(path, content)
      }
      // Add a README for the exported project
      zip.file(
        'generated-app/README.md',
        `# Aamoza Generated Android Project

Open this folder in Android Studio (File → Open).

If Gradle Wrapper JAR is missing, Android Studio will offer to generate it automatically.

Created with ${APP_NAME} by ${APP_AUTHOR} (v${APP_VERSION})
`
      )
      const blob = await zip.generateAsync({ type: 'blob' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `aamoza-android-project-${Date.now()}.zip`
      a.click()
      URL.revokeObjectURL(url)
      showToast('Project ZIP downloaded', 'ok')
    } catch (e: any) {
      showToast(e.message || 'ZIP failed', 'err')
    }
  }

  // ---- Explain code ----
  const explainFile = async () => {
    if (!selectedFile || !files[selectedFile] || aiStatus !== 'connected') return
    setBusy(true)
    setExplainText('Generating explanation…')
    try {
      let text: string
      if (provider === 'gemini') {
        text = await explainCodeGemini(apiKey.trim(), model, selectedFile, files[selectedFile])
      } else {
        text = await explainCodeDeepSeek(apiKey.trim(), model, selectedFile, files[selectedFile])
      }
      setExplainText(text)
    } catch (e: any) {
      setExplainText(`Error: ${e.message}`)
    } finally {
      setBusy(false)
    }
  }

  // ---- Push & Build ----
  const pushAndBuild = async () => {
    if (ghStatus !== 'connected') {
      showToast('Connect GitHub first', 'err')
      return
    }
    setBuild({ status: 'pushing', message: 'Pushing files to GitHub…' })
    setBusy(true)
    setProgress('build')
    try {
      const { commitSha, branch } = await pushFilesToGitHub(
        ghOwner,
        ghRepo,
        ghToken,
        files,
        'Aamoza: generate/update Android app'
      )
      setBuild({
        status: 'building',
        message: `Pushed to ${branch} (${commitSha.slice(0, 7)}). Waiting for GitHub Actions…`,
      })
      showToast('Code pushed! Build started.', 'ok')

      for (let i = 0; i < 12; i++) {
        await new Promise((r) => setTimeout(r, 5000))
        const run = await getLatestWorkflowRun(ghOwner, ghRepo, ghToken)
        if (run) {
          if (run.status === 'completed') {
            if (run.conclusion === 'success') {
              let extra = ''
              if (run.id) {
                const hint = await getArtifactDownloadHint(ghOwner, ghRepo, ghToken, run.id)
                if (hint) extra = ' ' + hint
              }
              setBuild({
                status: 'success',
                message:
                  'Build succeeded! Download the APK from the Actions → Artifacts section.' + extra,
                runUrl: run.html_url,
              })
            } else {
              setBuild({
                status: 'failed',
                message: `Build ${run.conclusion || 'failed'}. Check the workflow log.`,
                runUrl: run.html_url,
              })
            }
            break
          } else {
            setBuild((b) => ({
              ...b,
              message: `Build in progress… (${run.status})`,
              runUrl: run.html_url,
            }))
          }
        }
      }
    } catch (e: any) {
      setBuild({ status: 'failed', message: e.message || 'Push failed' })
      showToast(e.message || 'Push failed', 'err')
    } finally {
      setBusy(false)
    }
  }

  const onImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!file.type.startsWith('image/')) {
      showToast('Please select an image', 'err')
      return
    }
    if (provider !== 'gemini') {
      showToast('Image input is supported with Gemini only', 'err')
      return
    }
    const reader = new FileReader()
    reader.onload = () => setImagePreview(reader.result as string)
    reader.readAsDataURL(file)
  }

  const fileList = useMemo(() => Object.keys(files).sort(), [files])
  const changedPaths = useMemo(() => {
    const set = new Set<string>()
    for (const p of Object.keys(files)) {
      if (prevFiles[p] !== undefined && prevFiles[p] !== files[p]) set.add(p)
    }
    for (const p of Object.keys(prevFiles)) {
      if (files[p] === undefined) set.add(p)
    }
    return set
  }, [files, prevFiles])

  const stepIndex = (s: ProgressStep) =>
    ({ idle: 0, ai: 1, code: 2, github: 3, build: 4 }[s] || 0)

  return (
    <div className="app">
      {/* Header */}
      <header className="header">
        <div className="brand">
          <span className="logo">🤖</span>
          <div>
            <div className="brand-title">{APP_NAME}</div>
            <div className="brand-sub">{APP_TAGLINE} · by {APP_AUTHOR}</div>
          </div>
        </div>
        <div className="header-actions">
          <span className={`pill ${aiStatus === 'connected' ? 'ok' : aiStatus === 'error' ? 'err' : ''}`}>
            <span className="dot" />
            AI: {aiStatus === 'connected' ? 'Connected' : aiStatus === 'testing' ? 'Testing…' : aiStatus === 'error' ? 'Error' : 'Not connected'}
          </span>
          <span className={`pill ${ghStatus === 'connected' ? 'ok' : ghStatus === 'error' ? 'err' : ''}`}>
            <span className="dot" />
            GitHub: {ghStatus === 'connected' ? 'Connected' : ghStatus === 'testing' ? 'Testing…' : ghStatus === 'error' ? 'Error' : 'Not connected'}
          </span>
          <button className="ghost" onClick={() => setShowHistory(true)} title="Chat history">
            📂 History
          </button>
          <button className="ghost" onClick={() => setShowGuide(true)}>📖 Guide</button>
          <button className="ghost" onClick={newChat}>✨ New Chat</button>
        </div>
      </header>

      {/* Progress steps */}
      <div className="progress-bar">
        {(['ai', 'code', 'github', 'build'] as ProgressStep[]).map((s, i) => (
          <div
            key={s}
            className={`progress-step ${stepIndex(progress) >= i + 1 ? 'done' : ''} ${progress === s ? 'active' : ''}`}
          >
            <span className="num">{i + 1}</span>
            <span className="label">
              {s === 'ai' ? 'Connect AI' : s === 'code' ? 'Generate code' : s === 'github' ? 'GitHub' : 'Build APK'}
            </span>
          </div>
        ))}
      </div>

      <div className="main">
        {/* Left sidebar – settings */}
        <aside className="sidebar">
          <div className="section-title">AI Provider</div>
          <div className="field">
            <label>Provider</label>
            <select
              value={provider}
              onChange={(e) => setProvider(e.target.value as AIProvider)}
            >
              {PROVIDERS.map((p) => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          </div>
          <div className="field">
            <label>Model</label>
            <select value={model} onChange={(e) => setModel(e.target.value)}>
              {providerCfg.models.map((m) => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>
          <div className="field">
            <label>
              API Key{' '}
              <a href={providerCfg.docsUrl} target="_blank" rel="noreferrer" style={{ color: 'var(--accent2)', fontSize: 11 }}>
                Get key
              </a>
            </label>
            <div className="input-with-toggle">
              <input
                type={showApiKey ? 'text' : 'password'}
                placeholder={providerCfg.keyPlaceholder}
                value={apiKey}
                onChange={(e) => {
                  setApiKey(e.target.value)
                  setAiStatus('idle')
                  setAiStatusMsg('')
                }}
                autoComplete="off"
              />
              <button type="button" className="toggle-vis" onClick={() => setShowApiKey((v) => !v)}>
                {showApiKey ? 'Hide' : 'Show'}
              </button>
            </div>
          </div>
          <div className="btn-row">
            <button className="primary" onClick={testAI} disabled={busy || aiStatus === 'testing'}>
              {aiStatus === 'testing' ? 'Testing…' : 'Test Connection'}
            </button>
          </div>
          {aiStatusMsg && (
            <div className={`status-box ${aiStatus === 'connected' ? 'ok' : aiStatus === 'error' ? 'err' : ''}`}>
              {aiStatusMsg}
            </div>
          )}

          <div className="section-title">GitHub</div>
          <div className="field">
            <label>Username / Owner</label>
            <input
              placeholder="your-username"
              value={ghOwner}
              onChange={(e) => { setGhOwner(e.target.value); setGhStatus('idle') }}
            />
          </div>
          <div className="field">
            <label>Repository</label>
            <input
              placeholder="my-android-app"
              value={ghRepo}
              onChange={(e) => { setGhRepo(e.target.value); setGhStatus('idle') }}
            />
          </div>
          <div className="field">
            <label>
              Fine-grained PAT{' '}
              <a href="https://github.com/settings/tokens?type=beta" target="_blank" rel="noreferrer" style={{ color: 'var(--accent2)', fontSize: 11 }}>
                Create token
              </a>
            </label>
            <div className="input-with-toggle">
              <input
                type={showGhToken ? 'text' : 'password'}
                placeholder="github_pat_..."
                value={ghToken}
                onChange={(e) => { setGhToken(e.target.value); setGhStatus('idle') }}
                autoComplete="off"
              />
              <button type="button" className="toggle-vis" onClick={() => setShowGhToken((v) => !v)}>
                {showGhToken ? 'Hide' : 'Show'}
              </button>
            </div>
            <p className="hint">
              Required: <strong>Contents: Read and write</strong> for the target repo.
              Prefer a fine-grained token limited to one repository.
            </p>
          </div>
          <div className="btn-row">
            <button className="primary" onClick={testGitHub} disabled={busy || ghStatus === 'testing'}>
              {ghStatus === 'testing' ? 'Connecting…' : 'Connect GitHub'}
            </button>
          </div>
          {ghStatusMsg && (
            <div className={`status-box ${ghStatus === 'connected' ? 'ok' : ghStatus === 'error' ? 'err' : ''}`}>
              {ghStatusMsg}
            </div>
          )}

          <div className="section-title">Build & Export</div>
          <button
            className="primary"
            style={{ width: '100%', marginBottom: 8 }}
            onClick={pushAndBuild}
            disabled={busy || ghStatus !== 'connected'}
          >
            {build.status === 'pushing' ? 'Pushing…' : build.status === 'building' ? 'Building…' : 'Push & Build APK'}
          </button>
          <button
            className="secondary"
            style={{ width: '100%' }}
            onClick={downloadZip}
            disabled={fileList.length === 0}
          >
            📦 Download Project ZIP
          </button>
          {build.message && (
            <div className={`build-card ${build.status === 'success' ? 'success' : build.status === 'failed' ? 'failed' : ''}`}>
              <div style={{ fontSize: 13 }}>{build.message}</div>
              {build.runUrl && (
                <a href={build.runUrl} target="_blank" rel="noreferrer">
                  Open workflow →
                </a>
              )}
            </div>
          )}

          <label className="checkbox-row">
            <input
              type="checkbox"
              checked={persistKeys}
              onChange={(e) => setPersistKeys(e.target.checked)}
            />
            <span>Temporarily save keys in this browser</span>
          </label>
          {persistKeys && (
            <p className="hint warn">
              Keys are stored in localStorage on this device only. Clear them when done.
            </p>
          )}

          <p style={{ marginTop: 12, fontSize: 11, color: 'var(--muted)' }}>
            Keys stay in your browser. Calls go only to Gemini / DeepSeek / GitHub APIs you choose.
          </p>
        </aside>

        {/* Chat */}
        <section className="chat-area">
          <div className="messages">
            {messages.length === 0 && (
              <div className="welcome">
                <div style={{ fontSize: 40 }}>🤖</div>
                <h1>Build Android apps with AI</h1>
                <p>
                  Connect Gemini or DeepSeek with your own API key, chat to generate code,
                  download a ZIP or push to GitHub and get a real APK via Actions.
                </p>
                <div className="suggestions">
                  {PROMPT_TEMPLATES.map((t) => (
                    <button
                      key={t.id}
                      onClick={() => sendMessage(t.prompt)}
                      disabled={aiStatus !== 'connected' || busy}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
            {messages.map((m) => (
              <div key={m.id} className={`msg ${m.role}`}>
                <div className="role">{m.role === 'user' ? 'You' : 'AI'}</div>
                <div className="msg-body">{m.content}</div>
              </div>
            ))}
            {busy && <div className="typing">AI is thinking…</div>}
            <div ref={messagesEndRef} />
          </div>
          <div className="composer">
            {imagePreview && (
              <div className="image-chip">
                <img src={imagePreview} alt="attach" />
                <button type="button" onClick={() => setImagePreview(null)}>×</button>
              </div>
            )}
            <textarea
              placeholder={
                aiStatus === 'connected'
                  ? 'Describe the Android app you want… (Shift+Enter for newline)'
                  : 'Test AI connection first'
              }
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault()
                  sendMessage()
                }
              }}
              disabled={aiStatus !== 'connected' || busy}
              rows={2}
            />
            <div className="composer-actions">
              <input
                type="file"
                accept="image/*"
                ref={fileInputRef}
                style={{ display: 'none' }}
                onChange={onImageSelect}
              />
              <button
                type="button"
                className="ghost icon-btn"
                title="Attach screenshot (Gemini Vision)"
                disabled={provider !== 'gemini' || aiStatus !== 'connected' || busy}
                onClick={() => fileInputRef.current?.click()}
              >
                🖼️
              </button>
              <button
                className="send"
                onClick={() => sendMessage()}
                disabled={!input.trim() || aiStatus !== 'connected' || busy}
              >
                Send
              </button>
            </div>
          </div>
        </section>

        {/* Files */}
        <aside className="files-panel">
          <div className="section-title row">
            <span>Project Files ({fileList.length})</span>
            {selectedFile && aiStatus === 'connected' && (
              <button className="ghost tiny" onClick={explainFile} disabled={busy}>
                Explain
              </button>
            )}
          </div>
          <ul className="file-list">
            {fileList.map((path) => (
              <li
                key={path}
                className={`${selectedFile === path ? 'active' : ''} ${changedPaths.has(path) ? 'changed' : ''}`}
                onClick={() => {
                  setSelectedFile(path === selectedFile ? null : path)
                  setExplainText(null)
                }}
              >
                <span className="path">{path.replace('generated-app/', '')}</span>
                {changedPaths.has(path) && <span className="badge">edited</span>}
              </li>
            ))}
          </ul>
          {selectedFile && files[selectedFile] && (
            <div className="file-preview-wrap">
              <pre className="file-preview">
                <code className={`language-${langForPath(selectedFile)}`}>
                  {files[selectedFile]}
                </code>
              </pre>
              {explainText && (
                <div className="explain-box">
                  <strong>Explanation</strong>
                  <p>{explainText}</p>
                </div>
              )}
            </div>
          )}
        </aside>
      </div>

      {/* Footer */}
      <footer className="footer">
        <div>
          {APP_NAME} v{APP_VERSION} · by {APP_AUTHOR} ·{' '}
          <a href="https://github.com/aamoza/aamoza" target="_blank" rel="noreferrer">
            GitHub
          </a>
          {' · '}MIT License
        </div>
        <div>
          ☕ Support — BNB: <span className="wallet">{BNB_WALLET}</span>
        </div>
      </footer>

      {/* Guide modal */}
      {showGuide && (
        <div className="modal-backdrop" onClick={() => setShowGuide(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h2>How to use {APP_NAME}</h2>
            <div className="steps">
              <div className="step">
                <div className="step-num">1</div>
                <div>
                  <strong>Choose AI provider</strong>
                  <span>Select Google Gemini or DeepSeek and paste your own API key. Click “Test Connection”.</span>
                </div>
              </div>
              <div className="step">
                <div className="step-num">2</div>
                <div>
                  <strong>Chat & generate code</strong>
                  <span>Use templates or describe the app. With Gemini you can also attach a UI screenshot.</span>
                </div>
              </div>
              <div className="step">
                <div className="step-num">3</div>
                <div>
                  <strong>Download or connect GitHub</strong>
                  <span>Download a ZIP for Android Studio, or connect a fine-grained PAT (Contents: Read and write).</span>
                </div>
              </div>
              <div className="step">
                <div className="step-num">4</div>
                <div>
                  <strong>Push & Build APK</strong>
                  <span>Click “Push & Build APK”. GitHub Actions compiles a debug APK. Download it from Artifacts.</span>
                </div>
              </div>
            </div>
            <p style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 16 }}>
              No backend · Your keys never leave your browser except to the official Gemini / DeepSeek / GitHub APIs.
            </p>
            <div style={{ marginBottom: 12 }}>
              <strong>☕ Support This Project</strong>
              <p style={{ fontSize: 13, color: 'var(--muted)', marginTop: 4 }}>
                If {APP_NAME} helped you, support development:
              </p>
              <div className="wallet" style={{ marginTop: 6 }}>{BNB_WALLET}</div>
            </div>
            <button className="primary" style={{ width: '100%' }} onClick={() => setShowGuide(false)}>
              Got it
            </button>
          </div>
        </div>
      )}

      {/* History modal */}
      {showHistory && (
        <div className="modal-backdrop" onClick={() => setShowHistory(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h2>Chat history</h2>
            {sessions.length === 0 ? (
              <p style={{ color: 'var(--muted)' }}>No saved chats yet. They appear after you generate code.</p>
            ) : (
              <ul className="history-list">
                {sessions.map((s) => (
                  <li key={s.id}>
                    <button className="history-item" onClick={() => loadSession(s)}>
                      <span className="hist-title">{s.title}</span>
                      <span className="hist-meta">
                        {new Date(s.updatedAt).toLocaleString()} · {Object.keys(s.files).length} files
                      </span>
                    </button>
                    <button className="ghost tiny danger" onClick={() => deleteSession(s.id)}>
                      Delete
                    </button>
                  </li>
                ))}
              </ul>
            )}
            <button className="primary" style={{ width: '100%', marginTop: 12 }} onClick={() => setShowHistory(false)}>
              Close
            </button>
          </div>
        </div>
      )}

      {toast && (
        <div className={`toast ${toast.type}`}>{toast.text}</div>
      )}
    </div>
  )
}
