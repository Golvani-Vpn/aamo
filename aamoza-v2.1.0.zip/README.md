# Aamoza – AI Android Maker

**Aamoza** is a free, open-source, fully client-side tool by **aamoza** that lets anyone create real Android applications using their own AI API keys and their own GitHub account.

No backend. No server. No accounts on our side. Everything runs in your browser and talks directly to Google Gemini / DeepSeek and the GitHub API.

**Version:** 2.1.0

---

## Features

- **Bring your own AI key** — Google Gemini or DeepSeek
- **Real connection test** before chatting
- **Prompt templates** — Counter, Todo, Weather, Calculator, Bottom Nav, Theme toggle
- **Multi-chat history** (localStorage) — switch between projects
- **Structured code generation** (JSON files + delete list) with self-repair loop
- **Smart context** — only relevant project files are sent to the model
- **Syntax-highlighted file preview** + **Explain code** button
- **Diff markers** on recently changed files
- **Download project as ZIP** — open directly in Android Studio
- **GitHub integration** via Fine-grained Personal Access Token
- **Auto-adds build workflow** if missing in the repo
- **One-click push** + improved build status polling + artifact guidance
- **Gemini Vision** — attach a UI screenshot and ask to build it
- **Show/Hide keys** + optional temporary key persistence (with warning)
- **Progress steps** UI (Connect AI → Generate → GitHub → Build)
- **Modern dark UI** · GitHub Pages ready · pure static site

---

## Architecture

```
Browser (React + TypeScript + Vite)
    │
    ├──► Google Gemini API  (your key)
    ├──► DeepSeek API       (your key)
    └──► GitHub API         (your fine-grained token)
              │
              ▼
         Your repository
              │
              ▼
      GitHub Actions (build-android.yml)
              │
              ▼
         Debug APK artifact
```

There is **no application backend**, no database, no proxy, and no Docker service required to use the builder.

---

## Supported AI Providers

| Provider       | Models (examples)                          | Get API Key                              |
|----------------|--------------------------------------------|------------------------------------------|
| Google Gemini  | gemini-2.0-flash, gemini-2.0-flash-lite, … | https://aistudio.google.com/apikey       |
| DeepSeek       | deepseek-chat, deepseek-reasoner           | https://platform.deepseek.com/api_keys   |

---

## Quick Start (local)

```bash
git clone https://github.com/aamoza/aamoza.git
cd aamoza
npm install
npm run dev
```

Open http://localhost:5173

---

## Deploy to GitHub Pages

1. Fork or push this repository to GitHub.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, select **GitHub Actions**.
4. The workflow `.github/workflows/pages.yml` will build and publish the site on every push to `main`.
5. Your site will be available at:
   `https://<username>.github.io/aamoza/`

> The Vite `base` is set to `./` so relative paths work on project pages.

---

## How to use (step by step)

### 1. Open the app
Visit the GitHub Pages URL or run it locally.

### 2. Choose AI provider
Select **Google Gemini** or **DeepSeek**.

### 3. Add your API key
Paste the key. Use **Show/Hide** as needed.  
Keys are kept only in browser memory by default (optional temporary save available).

### 4. Test Connection
Click **Test Connection**. You should see a success message.

### 5. Start chatting
Use a template button or describe the Android app you want.  
With Gemini you can attach a screenshot of a UI design.

### 6. Download ZIP or Connect GitHub
- **Download Project ZIP** — open in Android Studio without GitHub.
- Or connect GitHub with a **fine-grained PAT** (Contents: Read and write).

### 7. Push & Build APK
Click **Push & Build APK**.  
GitHub Actions builds a debug APK. Open the workflow link and download from **Artifacts**.

---

## Project layout (generated Android app)

```
generated-app/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── gradlew
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/example/aamoza/MainActivity.kt
        └── res/values/…
```

---

## Security

- API keys and GitHub tokens are **never** stored in the repository.
- By default they live only in the current browser tab’s memory.
- Optional “temporarily save keys” uses localStorage on **your device only**.
- All network calls go directly from your browser to official APIs.
- No third-party analytics or tracking is included.

**Recommendation:** Use Fine-grained tokens limited to a single repository and revoke them when finished.

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Invalid API Key | Double-check the key and provider |
| API quota exceeded | Wait or upgrade the plan |
| Repository not found | Token must have access to that repo |
| Permission denied | Token needs **Contents: Read and write** |
| Empty repository | Push an initial commit (e.g. README) first |
| Build fails on Actions | Open the workflow log; check Gradle / SDK |
| CORS / network error | Check browser console; proxies may block APIs |

---

## Development

```bash
npm install
npm run dev          # Vite dev server
npm run build        # Production build → dist/
npm run typecheck    # TypeScript check
```

---

## License

MIT © aamoza

☕ Support: BNB `0xC47C7382F5D2EF81d6A5698fB1acFAe7A2FBC8f2`
